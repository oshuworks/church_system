<?php
require_once __DIR__ . '/bootstrap.php';

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

// POST: Track actual costs (labor, materials, overhead) (Requirement 3b)
if ($method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true) ?? [];
    
    $required = ['project_id', 'task_id', 'cost_type', 'amount'];
    foreach ($required as $field) {
        if (!isset($input[$field])) respond(['error' => "Missing: $field"], 400);
    }

    $projectId = (int)$input['project_id'];
    $taskId = (int)$input['task_id'];
    $type = $input['cost_type']; // 'labor', 'material', 'overhead'
    $amount = (float)$input['amount'];
    $description = $input['description'] ?? '';
    $referenceId = $input['reference_id'] ?? null; // e.g., employee_id or equipment_id

    // 1. Record the expense in a new transaction table (you should create this table)
    $sql = "INSERT INTO actual_costs (project_id, task_id, cost_type, amount, description, reference_id, transaction_date) 
            VALUES (?, ?, ?, ?, ?, ?, NOW())";
    runQuery($mysqli, $sql, ['iisdis', [$projectId, $taskId, $type, $amount, $description, $referenceId]]);

    // 2. Update the spent_amount in project_budgets (Real-time integration - Requirement 3d)
    // We map cost_type to a category_id (this logic assumes labor=1, material=2, etc.)
    $categoryMap = ['labor' => 1, 'material' => 2, 'overhead' => 3];
    $catId = $categoryMap[$type] ?? 1;

    $updateSql = "UPDATE project_budgets 
                  SET spent_amount = spent_amount + ?, 
                      remaining_amount = allocated_amount - (spent_amount)
                  WHERE project_id = ? AND category_id = ?";
    runQuery($mysqli, $updateSql, ['dii', [$amount, $projectId, $catId]]);

    respond(['message' => 'Expense logged and budget updated']);
}

// GET: List actual costs
if ($method === 'GET') {
    $projectId = (int)($_GET['project_id'] ?? 0);
    $sql = "SELECT ac.*, p.project_name, t.task_name 
            FROM actual_costs ac
            JOIN projects p ON ac.project_id = p.project_id
            JOIN tasks t ON ac.task_id = t.task_id";
    if ($projectId > 0) $sql .= " WHERE ac.project_id = $projectId";
    
    respond(['costs' => fetchAllAssoc(runQuery($mysqli, $sql))]);
}