<?php
require_once __DIR__ . '/bootstrap.php';

/**
 * Budget Expenses API
 * Fetches individual expense records for a project or specific budget category.
 */

$projectId = isset($_GET['project_id']) ? (int)$_GET['project_id'] : 0;
$categoryId = isset($_GET['category_id']) ? (int)$_GET['category_id'] : 0;

$params = [];
$types = "";
$whereClauses = [];

if ($projectId > 0) {
    $whereClauses[] = "be.project_id = ?";
    $params[] = $projectId;
    $types .= "i";
}

if ($categoryId > 0) {
    $whereClauses[] = "pb.category_id = ?";
    $params[] = $categoryId;
    $types .= "i";
}

$whereSql = !empty($whereClauses) ? "WHERE " . implode(" AND ", $whereClauses) : "";

$sql = "SELECT 
            be.expense_id,
            be.expense_description,
            be.amount,
            be.expense_date,
            be.expense_type,
            be.status,
            p.project_name,
            bc.category_name,
            t.task_name
        FROM budget_expenses be
        JOIN projects p ON be.project_id = p.project_id
        JOIN project_budgets pb ON be.budget_id = pb.budget_id
        JOIN budget_categories bc ON pb.category_id = bc.category_id
        LEFT JOIN tasks t ON be.task_id = t.task_id
        $whereSql
        ORDER BY be.expense_date DESC";

$stmt = runQuery($mysqli, $sql, [$types, $params]);
$expenses = fetchAllAssoc($stmt);

respond([
    'count' => count($expenses),
    'expenses' => $expenses
]);