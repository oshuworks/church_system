<?php
$activePage = 'budget';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>iServe Budgeting & Costs</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
    <link href="css/navbar.css" rel="stylesheet">
    <link href="css/resources.css" rel="stylesheet">
</head>
<body>
    <?php include __DIR__ . '/includes/navbar.php'; ?>

    <main class="container my-4">
        <!-- Header Section -->
        <section class="row align-items-center mb-4">
            <div class="col-md-8">
                <h1 class="fw-bold text-primary mb-2">Budgeting & Costs</h1>
                <p class="text-muted mb-0">Track project allocations, actual spending, and financial variances.</p>
            </div>
            <div class="col-md-4 text-md-end mt-3 mt-md-0">
                <button class="btn btn-primary me-2" id="refresh-budget-btn"><i class="fas fa-rotate me-1"></i>Refresh Data</button>
            </div>
        </section>

        <!-- Summary Metric Cards -->
        <section class="row g-3 mb-4" id="budget-summary-cards">
            <div class="col-md-3">
                <div class="card shadow-sm h-100">
                    <div class="card-body border-start border-primary border-4 rounded-1">
                        <div class="d-flex align-items-center justify-content-between mb-2">
                            <span class="text-uppercase text-muted small fw-bold">Total Budgeted</span>
                            <i class="fas fa-wallet text-primary"></i>
                        </div>
                        <h3 class="fw-bold mb-1" id="total-budgeted">$0.00</h3>
                        <p class="small text-muted mb-0">Across <span id="active-project-count">0</span> projects</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card shadow-sm h-100">
                    <div class="card-body border-start border-danger border-4 rounded-1">
                        <div class="d-flex align-items-center justify-content-between mb-2">
                            <span class="text-uppercase text-muted small fw-bold">Total Spent</span>
                            <i class="fas fa-receipt text-danger"></i>
                        </div>
                        <h3 class="fw-bold mb-1" id="total-spent">$0.00</h3>
                        <div class="progress mt-2" style="height: 6px;">
                            <div id="budget-burn-progress" class="progress-bar bg-danger" role="progressbar" style="width: 0%"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card shadow-sm h-100">
                    <div class="card-body border-start border-success border-4 rounded-1">
                        <div class="d-flex align-items-center justify-content-between mb-2">
                            <span class="text-uppercase text-muted small fw-bold">Remaining</span>
                            <i class="fas fa-chart-line text-success"></i>
                        </div>
                        <h3 class="fw-bold mb-1" id="total-variance">$0.00</h3>
                        <p class="small text-muted mb-0" id="variance-label">Available for allocation</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card shadow-sm h-100">
                    <div class="card-body border-start border-warning border-4 rounded-1">
                        <div class="d-flex align-items-center justify-content-between mb-2">
                            <span class="text-uppercase text-muted small fw-bold">Budget Alerts</span>
                            <i class="fas fa-triangle-exclamation text-warning"></i>
                        </div>
                        <h3 class="fw-bold mb-1" id="budget-alerts-count">0</h3>
                        <p class="small text-muted mb-0">Over-budget or nearing limit</p>
                    </div>
                </div>
            </div>
        </section>

        <div class="row">
            <!-- Left Column: Forms and Alerts -->
            <div class="col-lg-4">
                <!-- Log Expense Form -->
                <section class="card shadow-sm mb-4">
                    <div class="card-body">
                        <h5 class="fw-bold mb-3">Log New Expense</h5>
                        <form id="expense-form" class="row g-3">
                            <div class="col-12">
                                <label class="form-label small fw-bold">Project</label>
                                <select class="form-select" id="expense-project" required>
                                    <option value="">Select Project...</option>
                                </select>
                            </div>
                            <div class="col-12">
                                <label class="form-label small fw-bold">Category</label>
                                <select class="form-select" id="expense-category" required>
                                    <option value="labor">Labor / Workforce</option>
                                    <option value="equipment">Equipment & Tools</option>
                                    <option value="materials">Materials & Supplies</option>
                                    <option value="travel">Travel & Logistics</option>
                                    <option value="other">Other Overhead</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-bold">Amount ($)</label>
                                <input type="number" class="form-control" id="expense-amount" placeholder="0.00" step="0.01" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-bold">Date</label>
                                <input type="date" class="form-control" id="expense-date" value="<?php echo date('Y-m-d'); ?>" required>
                            </div>
                            <div class="col-12">
                                <label class="form-label small fw-bold">Notes</label>
                                <textarea class="form-control" id="expense-notes" rows="2" placeholder="Reference invoice or task..."></textarea>
                            </div>
                            <div class="col-12 mt-3">
                                <button type="submit" class="btn btn-primary w-100">
                                    <i class="fas fa-plus-circle me-1"></i>Record Transaction
                                </button>
                            </div>
                        </form>
                    </div>
                </section>

                <!-- Budget Alerts -->
                <section class="card shadow-sm mb-4">
                    <div class="card-header bg-white py-3">
                        <h6 class="mb-0 fw-bold"><i class="fas fa-bell text-danger me-2"></i>Financial Risk Alerts</h6>
                    </div>
                    <div class="card-body p-0">
                        <div id="budget-alerts-list" class="list-group list-group-flush">
                            <!-- Populated by JS -->
                            <div class="p-4 text-center text-muted small">Loading alerts...</div>
                        </div>
                    </div>
                </section>
            </div>

            <!-- Right Column: Tables and Lists -->
            <div class="col-lg-8">
                <!-- Project Financial Status Table -->
                <section class="card shadow-sm mb-4">
                    <div class="card-header bg-white d-flex justify-content-between align-items-center py-3">
                        <h6 class="mb-0 fw-bold">Project Financial Health</h6>
                        <span class="badge bg-light text-dark">Budget vs Actual</span>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light">
                                <tr>
                                    <th class="ps-3">Project</th>
                                    <th>Budget</th>
                                    <th>Actual Spent</th>
                                    <th class="text-center">Burn Rate</th>
                                    <th class="text-end pe-3">Status</th>
                                </tr>
                            </thead>
                            <tbody id="project-financials-body">
                                <tr><td colspan="5" class="text-center py-4">Loading financials...</td></tr>
                            </tbody>
                        </table>
                    </div>
                </section>

                <!-- Recent Transactions -->
                <section class="card shadow-sm">
                    <div class="card-header bg-white d-flex justify-content-between align-items-center py-3">
                        <h6 class="mb-0 fw-bold">Recent Transactions</h6>
                        <input type="search" id="expense-search" class="form-control form-control-sm w-25" placeholder="Search expenses...">
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light">
                                <tr>
                                    <th class="ps-3">Date</th>
                                    <th>Project</th>
                                    <th>Category</th>
                                    <th>Amount</th>
                                    <th class="text-end pe-3">Action</th>
                                </tr>
                            </thead>
                            <tbody id="expenses-log-body">
                                <tr><td colspan="5" class="text-center py-4">Loading transactions...</td></tr>
                            </tbody>
                        </table>
                    </div>
                </section>
            </div>
        </div>
    </main>

    <!-- Toasts for Feedback -->
    <div class="position-fixed bottom-0 end-0 p-3" style="z-index: 1080">
        <div id="toast-container"></div>
    </div>

    <?php include __DIR__ . '/includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/budgeting.js"></script>
</body>
</html>