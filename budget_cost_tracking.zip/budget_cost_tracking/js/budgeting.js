/**
 * iServe Budgeting & Cost Tracking Logic
 * Manages financial dashboard, expense logging, and real-time variance reporting.
 */

document.addEventListener('DOMContentLoaded', () => {
    // Initial data load
    fetchBudgetSummary();
    fetchProjectFinancials();
    loadDropdownData();

    // Event Listeners
    document.getElementById('refresh-budget-btn')?.addEventListener('click', () => {
        fetchBudgetSummary();
        fetchProjectFinancials();
        showToast('Updating financial data...', 'info');
    });

    document.getElementById('expense-form')?.addEventListener('submit', handleExpenseSubmit);
});

/**
 * Fetches high-level metrics for the summary cards
 */
async function fetchBudgetSummary() {
    try {
        const response = await fetch('api/budget_summary.php');
        const data = await response.json();

        if (data) {
            document.getElementById('total-budgeted').textContent = formatCurrency(data.budget.total_allocated);
            document.getElementById('total-spent').textContent = formatCurrency(data.budget.total_spent);
            document.getElementById('total-variance').textContent = formatCurrency(data.budget.variance);
            document.getElementById('active-project-count').textContent = data.projects.active_projects;
            document.getElementById('budget-alerts-count').textContent = data.alerts.critical + data.alerts.high;

            // Update burn rate progress bar
            const burnProgress = document.getElementById('budget-burn-progress');
            if (burnProgress) {
                const percent = Math.min(data.budget.utilization_percent, 100);
                burnProgress.style.width = percent + '%';
                burnProgress.className = `progress-bar ${percent > 90 ? 'bg-danger' : 'bg-success'}`;
            }
        }
    } catch (error) {
        console.error('Error fetching budget summary:', error);
    }
}

/**
 * Loads project lists into the form dropdown
 */
async function loadDropdownData() {
    try {
        // ✅ FIXED PATH (cross-module)
        const projRes = await fetch('../project_management/api/projects.php');
        const projects = await projRes.json();
        const projectSelect = document.getElementById('expense-project');

        if (projectSelect && projects) {
            projectSelect.innerHTML =
                '<option value="">Select Project...</option>' +
                projects.map(p =>
                    `<option value="${p.project_id}">${p.project_name}</option>`
                ).join('');
        }
    } catch (error) {
        console.error('Error loading dropdowns:', error);
    }
}

/**
 * Handles the submission of a new expense
 */
async function handleExpenseSubmit(e) {
    e.preventDefault();
    const btn = e.target.querySelector('button[type="submit"]');
    btn.disabled = true;

    const formData = {
        project_id: document.getElementById('expense-project').value,
        category_id: document.getElementById('expense-category').value,
        amount: document.getElementById('expense-amount').value,
        date: document.getElementById('expense-date').value,
        description: document.getElementById('expense-notes').value
    };

    try {
        const response = await fetch('api/costs.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(formData)
        });

        const result = await response.json();

        if (result.success) {
            showToast('Expense recorded successfully!', 'success');
            e.target.reset();
            fetchBudgetSummary();
            fetchProjectFinancials();
        } else {
            showToast(result.error || 'Failed to record expense', 'danger');
        }
    } catch (error) {
        showToast('Network error occurred', 'danger');
    } finally {
        btn.disabled = false;
    }
}

/**
 * Renders the project financial health table
 */
async function fetchProjectFinancials() {
    const tableBody = document.getElementById('project-financials-body');
    if (!tableBody) return;

    try {
        const response = await fetch('api/budget_expenses.php?all=true');
        const data = await response.json();

        tableBody.innerHTML = '';
        if (data.projects && data.projects.length > 0) {
            data.projects.forEach(proj => {
                const burnRate = proj.budget > 0 ? (proj.actual / proj.budget) * 100 : 0;
                const statusClass =
                    burnRate > 100 ? 'text-danger' :
                    burnRate > 90 ? 'text-warning' :
                    'text-success';

                tableBody.innerHTML += `
                    <tr>
                        <td class="ps-3 fw-bold">${proj.project_name}</td>
                        <td>${formatCurrency(proj.budget)}</td>
                        <td>${formatCurrency(proj.actual)}</td>
                        <td class="text-center">
                            <div class="progress" style="height: 10px; width: 100px; margin: 0 auto;">
                                <div class="progress-bar ${burnRate > 90 ? 'bg-danger' : 'bg-primary'}"
                                     role="progressbar"
                                     style="width: ${Math.min(burnRate, 100)}%"></div>
                            </div>
                            <small class="small ${statusClass}">${burnRate.toFixed(1)}%</small>
                        </td>
                        <td class="text-end pe-3">
                            <span class="status-pill status-${proj.status}">${proj.status}</span>
                        </td>
                    </tr>
                `;
            });
        } else {
            tableBody.innerHTML =
                '<tr><td colspan="5" class="text-center py-4">No financial data found.</td></tr>';
        }
    } catch (error) {
        tableBody.innerHTML =
            '<tr><td colspan="5" class="text-center text-danger py-4">Error loading financials.</td></tr>';
    }
}

/**
 * Helper: Formats numbers as USD currency
 */
function formatCurrency(amount) {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD'
    }).format(amount);
}

/**
 * Helper: Shows a Bootstrap toast message
 */
function showToast(message, type = 'primary') {
    const container = document.getElementById('toast-container');
    const toast = document.createElement('div');
    toast.className = `toast align-items-center text-white bg-${type} border-0 show mb-2`;
    toast.role = 'alert';
    toast.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">${message}</div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
    `;
    container.appendChild(toast);
    setTimeout(() => toast.remove(), 4000);
}
