# Minimal Design Theme — Implementation Notes

## What I changed ✅
- **Added** `css/minimal.css` — a lightweight minimal theme with neutral palette, readable typography, and simplified UI rules.
- **Imported** `minimal.css` into the main shared CSS files so it applies last:
  - `css/style.css` (via `@import url('minimal.css');`)
  - `css/resources.css` (via `@import url('minimal.css');`)
  - `css/navbar.css` (via `@import url('minimal.css');`)
- **Included** a fallback `<link rel="stylesheet" href="/css/minimal.css" />` in `includes/footer.php` so the minimal theme loads last for pages that don't import the shared CSS.

- **Added admin login & security improvements:** The site is restricted to an admin account. Default credentials are `admin` / `admin123` (change immediately) and are configured in `config/admin.php`. Implemented now: password hashing, an admin password-change page (`admin_change_password.php`), remember-me (persistent login) tokens, and rate-limiting (lockout after repeated failed logins). Login page: `admin_login.php`. I also adjusted the login colors and spacing for a warmer, clearer visual appearance, **removed the 'Forgot?' link** (it had no action), added a subtle top accent and logo tint on the login card for brand reinforcement, added a soft background tint behind the login card, and added a gentle background animation for subtle motion. The accent line is now a **solid** color (no hover animation). To revert the restriction, remove the redirect check in `includes/navbar.php`.
## Design goals
- Keep the DOM and JS untouched so all functionality remains functional.
- Use gentle overrides and a small set of utility rules so existing components (Gantt chart, tables, forms) continue to render correctly.
- Keep the stylesheet small and easy to edit.

## How to revert (if desired) ⚠️
- Remove the `@import url('minimal.css');` lines from:
  - `css/style.css`
  - `css/resources.css`
  - `css/navbar.css`
- Remove the `<link rel="stylesheet" href="/css/minimal.css" />` line from `includes/footer.php` (or comment it out).
- Optionally delete `css/minimal.css`.

## Notes & Next steps
- If you notice any page-specific visual regressions (particularly in modules that rely on heavy custom CSS), I can add targeted overrides rather than broad changes.
- To customize the minimal theme (colors, fonts), edit `css/minimal.css` variables at the top.

---
If you'd like, I can create a quick screenshot comparison or tweak the palette/typography to match your brand colors.