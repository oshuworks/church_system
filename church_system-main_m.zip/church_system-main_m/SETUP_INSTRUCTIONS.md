# Database Setup Instructions

## Problem
The resource allocation page is not showing any data (employees, equipment, projects, tasks, budgets, utilization) because the database is not set up.

## Solution

### Option 1: Use the Setup Script (Recommended)
1. Open your browser and navigate to:
   ```
   http://localhost/church_system-main_m/setup.php
   ```

2. The script will:
   - Create the `erp_project_management` database
   - Create all necessary tables
   - Insert sample data

3. After successful setup, visit:
   ```
   http://localhost/church_system-main_m/resource_allocation/resources.php
   ```

### Option 2: Manual Database Setup (Alternative)
If the setup script doesn't work, you can manually import the SQL files:

1. Open phpMyAdmin (usually at `http://localhost/phpmyadmin`)
2. Create a new database named `erp_project_management`
3. Import the following SQL files:
   - `sql/database.sql` (contains both main tables and resource allocation tables)
   - Or import separately:
     - `sql/erp_project_management.sql`
     - `resource_allocation/sql/resource_allocation_database.sql`

### Option 3: Run SQL Files Directly
If you have MySQL command line access:
```bash
mysql -u root -p erp_project_management < sql/database.sql
```

## Verification
After setup, verify the data is loaded by checking:
1. Visit `http://localhost/church_system-main_m/resource_allocation/resources.php`
2. You should see:
   - Summary cards with project/task counts
   - Alerts list
   - Employees table with data
   - Equipment table with data
   - Projects table with data
   - Tasks table with data
   - Utilization section

## Troubleshooting

### If you see "Database Connection Error"
- Check that MySQL is running (XAMPP Control Panel)
- Verify credentials in `includes/db.php` and `resource_allocation/api/bootstrap.php`
- Default credentials: root, no password, database: erp_project_management

### If tables exist but no data
- The SQL files include sample data. If you don't see it, re-import the SQL files.

### If you see "Loading..." forever
- Check browser console (F12) for JavaScript errors
- Check that all API files exist in their respective directories
- Verify the database connection test in resources.php shows no error

## Files Modified
- Created `sql/database.sql` by combining `sql/erp_project_management.sql` and `resource_allocation/sql/resource_allocation_database.sql`
- This allows the setup.php script to work correctly
