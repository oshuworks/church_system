# Quick Reference - Notification System

## 📋 What You Need to Know

### All Notification APIs Are Now in `/api/` Folder

**Old Way (❌ No Longer Used):**
- `project_management/api/notifications_api.php`
- `project_management/api/resource_balancing.php`

**New Way (✅ Use This):**
- `/api/notifications_api.php`
- `/api/resource_balancing.php`

---

## 🔧 How to Use

### 1. Fetch Notifications
```javascript
// Get all notifications
const response = await fetch(window.BASE_URL + '/api/notifications_api.php');

// Get only unread
const response = await fetch(window.BASE_URL + '/api/notifications_api.php?unread_only=true');

// Get only deadline notifications
const response = await fetch(window.BASE_URL + '/api/notifications_api.php?deadline_only=true');
```

### 2. Create Notification
```javascript
const formData = new FormData();
formData.append('notification_type', 'project_due_date');
formData.append('message', 'Project deadline approaching');
formData.append('project_id', '123');

const response = await fetch(window.BASE_URL + '/api/notifications_api.php', {
    method: 'POST',
    body: formData
});
```

### 3. Mark as Read
```javascript
const formData = new FormData();
formData.append('notification_id', '456');

const response = await fetch(window.BASE_URL + '/api/notifications_api.php', {
    method: 'PUT',
    body: formData
});
```

### 4. Delete Notification
```javascript
const formData = new FormData();
formData.append('notification_id', '456');

const response = await fetch(window.BASE_URL + '/api/notifications_api.php', {
    method: 'DELETE',
    body: formData
});
```

---

## 📁 File Locations

### Central API Files
```
/api/notifications_api.php          ← Main notification API
/api/resource_balancing.php         ← Resource utilization checker
/api/deadline_notifications.php     ← Deadline checker
```

### JavaScript Files (Updated)
```
/js/main.js                         ← All notification functions
/notifications.php                  ← Notification page
/budget_cost_tracking/js/budgeting.js ← Budget notifications
```

### Navbar Files (Updated)
```
erp_project_management/includes/navbar.php
project_management/includes/navbar.php
resource_allocation/includes/navbar.php
budget_cost_tracking/includes/navbar.php
```

---

## ✅ What Works Now

- ✅ All modules use same notification API
- ✅ Navbar notifications work across all pages
- ✅ Notification page shows all notifications
- ✅ Resource utilization alerts work
- ✅ Deadline notifications work
- ✅ Mark as read works
- ✅ Delete notifications works
- ✅ Badge counts update automatically

---

## 🎯 Quick Test

1. **Open any page** - Check navbar notification badge
2. **Click notification icon** - Should show dropdown with notifications
3. **Go to `/notifications.php`** - Should show full notification list
4. **Create a project** - Should trigger deadline notification
5. **Check resource utilization** - Should trigger utilization alerts

---

## 📞 Need Help?

All notification logic is now in:
- `/api/notifications_api.php` - API endpoints
- `/js/main.js` - JavaScript functions
- `/notifications.php` - Notification page

**No more scattered APIs! Everything is centralized.**
