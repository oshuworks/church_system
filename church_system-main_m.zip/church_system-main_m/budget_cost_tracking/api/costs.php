<?php
require_once __DIR__ . '/bootstrap.php';

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true) ?? [];
    
    if (!isset($input['project_id']) || !isset($input['amount'])) {
        respond(['error' => "Missing project_id or amount"], 400);
    }

    $projectId   = (int)$input['project_id'];
    $amount      = (float)$input['amount'];
    $description = $input['description'] ?? $input['notes'] ?? '';
    $type        = $input['cost_type'] ?? $input['category_id'] ?? 'other';

    $taskId = !empty($input['task_id']) ? (int)$input['task_id'] : null;

    $categoryMap = ['labor' => 1, 'materials' => 2, 'equipment' => 2, 'travel' => 3, 'other' => 3];
    $catId = $categoryMap[$type] ?? 1;

    // Check if budget exists for this project and category
    $budgetQuery = "SELECT budget_id FROM project_budgets WHERE project_id = ? AND category_id = ? LIMIT 1";
    $budgetResult = runQuery($mysqli, $budgetQuery, ['ii', [$projectId, $catId]]);
    $budgetData = fetchAllAssoc($budgetResult);

    if (empty($budgetData)) {
        // Try to find any budget for this project
        $fallbackQuery = "SELECT budget_id FROM project_budgets WHERE project_id = ? LIMIT 1";
        $fallbackResult = runQuery($mysqli, $fallbackQuery, ['i', [$projectId]]);
        $fallbackData = fetchAllAssoc($fallbackResult);
        
        if (empty($fallbackData)) {
            // No budget exists - check if project has budget allocated
            $projectBudgetQuery = "SELECT COALESCE(budget_allocated, 0) as project_budget FROM projects WHERE project_id = ? LIMIT 1";
            $projectBudgetResult = runQuery($mysqli, $projectBudgetQuery, ['i', [$projectId]]);
            $projectBudgetData = fetchAllAssoc($projectBudgetResult);
            $projectBudget = !empty($projectBudgetData) ? (float)($projectBudgetData[0]['project_budget'] ?? 0) : 0;
            
            if ($projectBudget <= 0) {
                // Project has no budget allocated - show alert
                respond([
                    'success' => false,
                    'error' => 'This project has no budget allocated yet. Please allocate a budget in Project Management before adding expenses.'
                ], 400);
                exit;
            }
            
            // Project has budget allocated - create budget entry using the project's allocated budget
            $fiscalYear = date('Y');
            $createBudgetSql = "INSERT INTO project_budgets (project_id, category_id, allocated_amount, spent_amount, fiscal_year, status) 
                               VALUES (?, ?, ?, 0, ?, 'active')";
            runQuery($mysqli, $createBudgetSql, ['idds', [$projectId, $catId, $projectBudget, $fiscalYear]]);
            
            // Get the newly created budget_id
            $newBudgetResult = runQuery($mysqli, $budgetQuery, ['ii', [$projectId, $catId]]);
            $newBudgetData = fetchAllAssoc($newBudgetResult);
            $budgetId = $newBudgetData[0]['budget_id'];
        } else {
            // Use existing budget from another category
            $budgetId = $fallbackData[0]['budget_id'];
        }
    } else {
        $budgetId = $budgetData[0]['budget_id'];
    }

    // Check remaining budget and prevent expenses that exceed allocated budget
    $budgetCheckSql = "SELECT allocated_amount, spent_amount FROM project_budgets WHERE budget_id = ? LIMIT 1";
    $budgetCheckRes = runQuery($mysqli, $budgetCheckSql, ['i', [$budgetId]]);
    $budgetInfo = fetchAllAssoc($budgetCheckRes)[0];

    $remaining = $budgetInfo['allocated_amount'] - $budgetInfo['spent_amount'];
    
    // Prevent expenses that exceed the remaining budget
    if ($amount > $remaining) {
        respond([
            'success' => false,
            'error' => "Expense exceeds remaining budget. Remaining: ₱" . number_format($remaining, 2) . " | Attempted: ₱" . number_format($amount, 2)
        ], 400);
        exit;
    }

    $sql = "INSERT INTO budget_expenses (project_id, budget_id, task_id, expense_description, amount, expense_type, expense_date) 
            VALUES (?, ?, ?, ?, ?, ?, NOW())";
    
    try {
        runQuery($mysqli, $sql, ['iiisds', [$projectId, $budgetId, $taskId, $description, $amount, $type]]);

        // Update spent_amount - remaining_amount is auto-calculated by MySQL (GENERATED column)
        $updateSql = "UPDATE project_budgets 
                      SET spent_amount = spent_amount + ?
                      WHERE budget_id = ?";
        
        runQuery($mysqli, $updateSql, ['di', [$amount, $budgetId]]);

        respond(['success' => true, 'message' => 'Expense logged successfully!']);

    } catch (Exception $e) {
        respond(['success' => false, 'error' => "Database error: " . $e->getMessage()], 500);
    }
}

if ($method === 'GET') {
    $projectId = (int)($_GET['project_id'] ?? 0);
    $sql = "SELECT be.*, p.project_name, t.task_name 
            FROM budget_expenses be
            LEFT JOIN projects p ON be.project_id = p.project_id
            LEFT JOIN tasks t ON be.task_id = t.task_id";
    if ($projectId > 0) $sql .= " WHERE be.project_id = $projectId";
    $sql .= " ORDER BY be.expense_date DESC";
    respond(['costs' => fetchAllAssoc(runQuery($mysqli, $sql))]);
}
