/**
 * iServe Budgeting & Cost Tracking Logic
 */

const projectBudgetCache = {};

document.addEventListener('DOMContentLoaded', () => {
    fetchBudgetSummary();
    fetchProjectFinancials();
    loadDropdownData();
    loadRecentTransactions();

    document.getElementById('refresh-budget-btn')?.addEventListener('click', () => {
        fetchBudgetSummary();
        fetchProjectFinancials();
        loadRecentTransactions();
        showToast('Updating financial data...', 'info');
    });

    document.getElementById('expense-form')?.addEventListener('submit', handleExpenseSubmit);
});

async function fetchBudgetSummary() {
    try {
        const response = await fetch(`${window.BASE_URL}/budget_cost_tracking/api/budget_summary.php`);
        const data = await response.json();
        if (!data) return;

        document.getElementById('total-budgeted').textContent = formatCurrency(data.budget.total_allocated);
        document.getElementById('total-spent').textContent = formatCurrency(data.budget.total_spent);
        document.getElementById('total-variance').textContent = formatCurrency(data.budget.variance);
        document.getElementById('active-project-count').textContent = data.projects.active_projects;
        document.getElementById('budget-alerts-count').textContent = data.alerts.critical + data.alerts.high;

        const burnProgress = document.getElementById('budget-burn-progress');
        if (burnProgress) {
            const percent = Math.min(data.budget.utilization_percent, 100);
            burnProgress.style.width = percent + '%';
            burnProgress.className = `progress-bar ${percent > 90 ? 'bg-danger' : 'bg-success'}`;
        }
    } catch (error) {
        console.error('Error fetching budget summary:', error);
    }
}

async function loadDropdownData() {
    try {
        const res = await fetch(`${window.BASE_URL}/project_management/api/projects.php`);
        const text = await res.text();
        let projects;
        try { projects = JSON.parse(text); } 
        catch { projects = []; }

        const projectSelect = document.getElementById('expense-project');
        if (!projectSelect) return;

        const projectList = Array.isArray(projects) ? projects : (projects.projects || []);
        projectSelect.innerHTML = projectList.length
            ? '<option value="">Select Project...</option>' + projectList.map(p => `<option value="${p.project_id}">${p.project_name || p.name}</option>`).join('')
            : '<option value="">No projects found</option>';
    } catch (error) {
        console.error('Error loading projects:', error);
    }
}

async function handleExpenseSubmit(e) {
    e.preventDefault();
    const btn = e.target.querySelector('button[type="submit"]');
    btn.disabled = true;
    const originalText = btn.innerHTML;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i> Saving...';

    const formData = {
        project_id: document.getElementById('expense-project').value,
        category_id: document.getElementById('expense-category').value,
        amount: document.getElementById('expense-amount').value,
        description: document.getElementById('expense-notes').value,
        task_id: null,
    };

    const budget = projectBudgetCache[formData.project_id];
    if (!budget) {
        showToast('Budget data not loaded. Please refresh.', 'warning');
        btn.disabled = false;
        btn.innerHTML = originalText;
        return;
    }

    const remaining = budget.allocated - budget.spent;
    if (parseFloat(formData.amount) > remaining) {
        showToast(`Expense exceeds remaining budget (₱${remaining.toFixed(2)})`, 'danger');
        btn.disabled = false;
        btn.innerHTML = originalText;
        return;
    }

    const submissionKey = `${formData.project_id}-${formData.amount}-${formData.category_id}`;
    if (window.lastSubmissionKey === submissionKey && (Date.now() - window.lastSubmissionTime < 5000)) {
        showToast('Duplicate entry detected. Please wait a moment.', 'warning');
        btn.disabled = false;
        btn.innerHTML = originalText;
        return;
    }

    try {
        const response = await fetch(`${window.BASE_URL}/budget_cost_tracking/api/costs.php`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(formData)
        });

        const result = await response.json();
        if (result.success) {
            window.lastSubmissionKey = submissionKey;
            window.lastSubmissionTime = Date.now();
            showToast('Expense recorded successfully!', 'success');
            e.target.reset();
            fetchBudgetSummary();
            fetchProjectFinancials();
            loadRecentTransactions();
        } else {
            showToast(result.error || 'Failed to record expense', 'danger');
        }
    } catch {
        showToast('Network error occurred', 'danger');
    } finally {
        setTimeout(() => {
            btn.disabled = false;
            btn.innerHTML = originalText;
        }, 1000);
    }
}

/** Load recent transactions including Notes */
async function loadRecentTransactions() {
    const tableBody = document.getElementById('expenses-log-body');
    if (!tableBody) return;

    try {
        const response = await fetch(`${window.BASE_URL}/budget_cost_tracking/api/costs.php`);
        const data = await response.json();

        if (data.costs && data.costs.length) {
            tableBody.innerHTML = data.costs.map(expense => `
                <tr>
                    <td class="ps-3 small">${new Date(expense.expense_date).toLocaleDateString()}</td>
                    <td><div class="fw-bold">${expense.project_name || 'N/A'}</div></td>
                    <td><span class="badge bg-light text-dark border text-uppercase">${expense.expense_type}</span></td>
                    <td class="fw-bold text-danger">₱${parseFloat(expense.amount).toLocaleString(undefined, {minimumFractionDigits: 2})}</td>
                    <td class="small text-muted">${expense.expense_description || ''}</td>
                </tr>
            `).join('');
        } else {
            tableBody.innerHTML = '<tr><td colspan="5" class="text-center py-4 text-muted">No recent transactions found.</td></tr>';
        }
    } catch (error) {
        console.error('Error loading transactions:', error);
        tableBody.innerHTML = '<tr><td colspan="5" class="text-center text-danger py-4">Error loading transactions.</td></tr>';
    }
}

// Rest of your functions (fetchProjectFinancials, formatCurrency, showToast) remain unchanged


/**
 * Renders the project financial health table
 */
async function fetchProjectFinancials() {
    const tableBody = document.getElementById('project-financials-body');
    if (!tableBody) return;

    try {
        const response = await fetch(window.BASE_URL + '/budget_cost_tracking/api/budget_expenses.php?all=true');
        const data = await response.json();

        tableBody.innerHTML = '';
        if (data.projects && data.projects.length > 0) {
            data.projects.forEach(proj => {
                const budget = parseFloat(proj.budget || 0);
                const actual = parseFloat(proj.actual || 0);

                // 🔒 Cache current budget info
                const projectId = proj.project_id;
                projectBudgetCache[projectId] = { allocated: budget, spent: actual };
                
                const burnRate = budget > 0 ? (actual / budget) * 100 : 0;
                const statusClass = burnRate > 100 ? 'text-danger' : burnRate > 90 ? 'text-warning' : 'text-success';

                tableBody.innerHTML += `
                    <tr>
                        <td class="ps-3 fw-bold">${proj.project_name}</td>
                        <td>${formatCurrency(budget)}</td>
                        <td>${formatCurrency(actual)}</td>
                        <td class="text-center">
                            <div class="progress mb-1" style="height: 6px; width: 100px; margin: 0 auto;">
                                <div class="progress-bar ${burnRate > 90 ? 'bg-danger' : 'bg-primary'}"
                                     style="width: ${Math.min(burnRate, 100)}%"></div>
                            </div>
                            <small class="${statusClass} fw-bold" style="font-size: 0.7rem;">${burnRate.toFixed(1)}%</small>
                        </td>
                        <td class="text-end pe-3">
                            <span class="badge ${burnRate > 100 ? 'bg-danger' : 'bg-success'} font-monospace" style="font-size: 0.65rem;">
                                ${proj.status ? proj.status.toUpperCase() : 'ACTIVE'}
                            </span>
                        </td>
                    </tr>
                `;
            });
        } else {
            tableBody.innerHTML = '<tr><td colspan="5" class="text-center py-4">No financial data found.</td></tr>';
        }
    } catch (error) {
        tableBody.innerHTML = '<tr><td colspan="5" class="text-center text-danger py-4">Error loading financials.</td></tr>';
    }
}

// ... rest of your functions (formatCurrency, showToast, loadExpensesTable) remain unchanged


function formatCurrency(amount) {
    return new Intl.NumberFormat('en-PH', {
        style: 'currency',
        currency: 'PHP'
    }).format(amount);
}

function showToast(message, type = 'primary') {
    // Use the main toast system if available
    if (typeof window.showToast === 'function') {
        // Map Bootstrap types to main toast types
        const typeMap = {
            'primary': 'info',
            'success': 'success',
            'danger': 'error',
            'warning': 'warning',
            'info': 'info'
        };
        const mainType = typeMap[type] || 'info';
        // main.js showToast signature: showToast(title, message, type, duration)
        window.showToast(null, message, mainType, 4000);
        return;
    }
    
    // Fallback to local implementation
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        container.className = 'toast-container';
        document.body.appendChild(container);
    }
    
    const toast = document.createElement('div');
    toast.className = `toast-notification toast-${type === 'danger' ? 'error' : type === 'primary' ? 'info' : type}`;
    
    const icons = {
        success: '<i class="fas fa-check-circle"></i>',
        error: '<i class="fas fa-exclamation-circle"></i>',
        warning: '<i class="fas fa-exclamation-triangle"></i>',
        info: '<i class="fas fa-info-circle"></i>'
    };
    
    const icon = icons[type === 'danger' ? 'error' : type === 'primary' ? 'info' : type] || icons.info;
    
    toast.innerHTML = `
        <div class="toast-icon">${icon}</div>
        <div class="toast-content">
            <div class="toast-message">${message}</div>
        </div>
        <button type="button" class="toast-close" onclick="this.closest('.toast-notification').remove()">
            <i class="fas fa-times"></i>
        </button>
        <div class="toast-progress"><div class="toast-progress-bar" style="animation-duration: 4000ms;"></div></div>
    `;
    
    container.appendChild(toast);
    
    // Trigger animation
    setTimeout(() => {
        toast.classList.add('show');
    }, 10);
    
    // Auto-remove after 4 seconds
    setTimeout(() => {
        if (toast.parentNode) {
            toast.classList.add('toast-exiting');
            setTimeout(() => toast.remove(), 300);
        }
    }, 4000);
}

function loadExpensesTable(expenses) {
    const logBody = document.getElementById('expenses-log-body');
    if (!logBody) return;

    logBody.innerHTML = expenses.map(item => `
        <tr>
            <td class="ps-3 py-3 small">${item.date}</td>
            <td class="small fw-semibold">${item.project_name || 'General'}</td>
            <td><span class="badge bg-light text-muted border fw-normal">${item.category}</span></td>
            <td class="fw-bold">₱${parseFloat(item.amount).toLocaleString()}</td>
            <td class="text-end pe-3">
                <button class="btn btn-sm btn-outline-primary px-3" onclick="editExpense(${item.id})">
                    <i class="fas fa-pen-to-square me-1"></i> Edit
                </button>
            </td>
        </tr>
    `).join('');
}

