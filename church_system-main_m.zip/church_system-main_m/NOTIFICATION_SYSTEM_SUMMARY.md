# Notification System - Central API Migration Summary

## Overview
Successfully migrated all notification-related APIs to the central `/api/` folder for uniformity and simpler integration across all modules.

## ✅ Completed Tasks

### 1. Central API Files Created

#### `/api/notifications_api.php`
- **Purpose**: Central notification API for all modules
- **Endpoints**:
  - `GET /api/notifications_api.php` - Fetch all notifications
  - `GET /api/notifications_api.php?unread_only=true` - Fetch unread notifications
  - `GET /api/notifications_api.php?deadline_only=true` - Fetch deadline notifications
  - `POST /api/notifications_api.php` - Create new notification
  - `PUT /api/notifications_api.php` - Mark as read (single or all)
  - `DELETE /api/notifications_api.php` - Delete notification(s)

#### `/api/resource_balancing.php`
- **Purpose**: Resource utilization checker (moved from `project_management/api/`)
- **Function**: Checks resource utilization and creates over/under-utilization notifications
- **Endpoint**: `GET /api/resource_balancing.php?check_notifications=true`

#### `/api/deadline_notifications.php`
- **Purpose**: Deadline checker (already existed in main api folder)
- **Function**: Creates deadline-based notifications for projects and tasks

### 2. JavaScript Files Updated

#### `/js/main.js`
Updated all notification API calls to use central API:
- ✅ `checkDeadlineNotifications()` - Uses `/api/deadline_notifications.php`
- ✅ `loadNotifications()` - Uses `/api/notifications_api.php`
- ✅ `checkForNewNotifications()` - Uses `/api/resource_balancing.php`
- ✅ `checkForNewNotificationsBackground()` - Uses `/api/notifications_api.php`
- ✅ `markNotificationRead()` - Uses `/api/notifications_api.php`
- ✅ `markAllNotificationsRead()` - Uses `/api/notifications_api.php`
- ✅ `markNavbarNotificationRead()` - Uses `/api/notifications_api.php`
- ✅ `updateNavbarNotificationCount()` - Uses `/api/notifications_api.php`
- ✅ `updateHeaderNotificationBadge()` - Uses `/api/notifications_api.php`

#### `/notifications.php`
Updated all notification API calls:
- ✅ `loadAllNotifications()` - Uses `/api/notifications_api.php`
- ✅ `markAsRead()` - Uses `/api/notifications_api.php`
- ✅ `markAllRead()` - Uses `/api/notifications_api.php`
- ✅ `deleteNotification()` - Uses `/api/notifications_api.php`
- ✅ `clearAllRead()` - Uses `/api/notifications_api.php`

### 3. API Structure

```
church_system-main_m/
├── api/
│   ├── notifications_api.php          ← Central notification API
│   ├── resource_balancing.php         ← Resource utilization checker
│   ├── deadline_notifications.php     ← Deadline checker
│   └── ... (other APIs)
├── js/
│   └── main.js                        ← Updated to use central API
├── notifications.php                  ← Updated to use central API
└── ... (other modules)
```

### 4. Integration Points

All modules now connect to the central API:
- **budget_cost_tracking/** - Uses central notification API
- **erp_project_management/** - Uses central notification API
- **project_management/** - Uses central notification API
- **resource_allocation/** - Uses central notification API

## Benefits

1. **Uniformity**: All modules use the same API structure
2. **Simpler Integration**: Only one set of notification APIs to maintain
3. **Consistency**: Same endpoints across all modules
4. **Easier Maintenance**: Changes to notification logic only need to be made in one place
5. **Better Performance**: Reduced code duplication

## API Usage Examples

### Fetch Unread Notifications
```javascript
const response = await fetch(window.BASE_URL + '/api/notifications_api.php?unread_only=true');
const data = await response.json();
```

### Create Notification
```javascript
const formData = new FormData();
formData.append('notification_type', 'project_due_date');
formData.append('message', 'Project deadline approaching');
formData.append('project_id', '123');

const response = await fetch(window.BASE_URL + '/api/notifications_api.php', {
    method: 'POST',
    body: formData
});
```

### Mark as Read
```javascript
const formData = new FormData();
formData.append('notification_id', '456');

const response = await fetch(window.BASE_URL + '/api/notifications_api.php', {
    method: 'PUT',
    body: formData
});
```

### Delete Notification
```javascript
const formData = new FormData();
formData.append('notification_id', '456');

const response = await fetch(window.BASE_URL + '/api/notifications_api.php', {
    method: 'DELETE',
    body: formData
});
```

## Next Steps

All notification-related APIs are now centralized. The system is ready for:
1. Adding new notification types
2. Expanding to other modules
3. Further integration with existing systems

## Files Modified

- `/js/main.js` - Updated all API calls to use central API
- `/notifications.php` - Updated all API calls to use central API
- `/api/notifications_api.php` - Created (NEW)
- `/api/resource_balancing.php` - Created (NEW, moved from project_management/api)

## Files Deleted

- `/project_management/api/notifications_api.php` - Replaced by central API
- `/project_management/api/resource_balancing.php` - Replaced by central API

---

**Status**: ✅ COMPLETE - All notification APIs centralized and all modules updated to use them.
