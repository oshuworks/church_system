(() => {
  // Use BASE_URL if available, otherwise default to 'api'
  const apiBase = (typeof window.BASE_URL !== 'undefined' && window.BASE_URL) 
    ? `${window.BASE_URL}/resource_allocation/api` 
    : 'api';
  const toastContainer = document.getElementById('toast-container');
  const seenAlertIds = new Set();
  const toastQueue = [];
  let isShowingToast = false;

  const moneyFmt = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'PHP' });
  const percentFmt = (value) => `${Number(value ?? 0).toFixed(0)}%`;
  let projectsCache = [];
  let tasksCache = [];
  let employeesCache = [];
  let equipmentCache = [];
  let budgetsCache = [];

  function processToastQueue() {
    if (isShowingToast || !toastQueue.length) return;
    isShowingToast = true;
    const { title, message, variant } = toastQueue.shift();
    
    // Use main toast system if available
    if (typeof window.showToast === 'function') {
      const typeMap = {
        'primary': 'info',
        'success': 'success',
        'danger': 'error',
        'warning': 'warning',
        'info': 'info'
      };
      const mainType = typeMap[variant] || 'info';
      // main.js showToast signature: showToast(message, type, title, duration)
      window.showToast(message, mainType, title, 4000);
      isShowingToast = false;
      processToastQueue();
      return;
    }
    
    // Fallback to local implementation
    let container = document.getElementById('toast-container');
    if (!container) {
      container = document.createElement('div');
      container.id = 'toast-container';
      container.className = 'toast-container';
      document.body.appendChild(container);
    }
    
    const toastEl = document.createElement('div');
    toastEl.className = `toast-notification toast-${variant === 'danger' ? 'error' : variant === 'primary' ? 'info' : variant}`;
    
    const icons = {
      success: '<i class="fas fa-check-circle"></i>',
      error: '<i class="fas fa-exclamation-circle"></i>',
      warning: '<i class="fas fa-exclamation-triangle"></i>',
      info: '<i class="fas fa-info-circle"></i>'
    };
    
    const icon = icons[variant === 'danger' ? 'error' : variant === 'primary' ? 'info' : variant] || icons.info;
    
    toastEl.innerHTML = `
      <div class="toast-icon">${icon}</div>
      <div class="toast-content">
        ${title ? `<div class="toast-title">${title}</div>` : ''}
        <div class="toast-message">${message}</div>
      </div>
      <button type="button" class="toast-close" onclick="this.closest('.toast-notification').remove()">
        <i class="fas fa-times"></i>
      </button>
      <div class="toast-progress"><div class="toast-progress-bar" style="animation-duration: 4000ms;"></div></div>
    `;
    
    container.appendChild(toastEl);
    
    // Trigger animation
    setTimeout(() => {
      toastEl.classList.add('show');
    }, 10);
    
    // Auto-remove after 4 seconds
    setTimeout(() => {
      if (toastEl.parentNode) {
        toastEl.classList.add('toast-exiting');
        setTimeout(() => {
          toastEl.remove();
          isShowingToast = false;
          processToastQueue();
        }, 300);
      }
    }, 4000);
  }

  function showToast(title, message, variant = 'primary') {
    toastQueue.push({ title, message, variant });
    processToastQueue();
  }

  async function fetchJSON(endpoint, options = {}) {
    const url = `${apiBase}/${endpoint}`;
    console.log(`Fetching: ${url}`);
    const res = await fetch(url, options);
    console.log(`Response status: ${res.status}`);
    if (!res.ok) {
      const text = await res.text();
      console.error(`Fetch error for ${url}:`, text);
      throw new Error(text || `Request failed (${res.status})`);
    }
    const data = await res.json();
    console.log(`Data received from ${url}:`, data);
    return data;
  }

  function renderSummary(data) {
    console.log('Rendering summary:', data);
    const { projects, tasks, budget, alerts, utilization, resources } = data;
    const setText = (id, value) => {
      const el = document.getElementById(id);
      if (el) {
        el.textContent = value;
        console.log(`Set ${id} to ${value}`);
      } else {
        console.warn(`Element ${id} not found`);
      }
    };

    setText('projects-total', projects?.total_projects ?? '--');
    setText('projects-active', projects?.active_projects ?? '--');
    setText('projects-completed', projects?.completed_projects ?? '--');

    setText('tasks-total', tasks?.total_tasks ?? '--');
    setText('tasks-in-progress', tasks?.in_progress_tasks ?? '--');
    setText('tasks-completed', tasks?.completed_tasks ?? '--');

    setText('budget-allocated', budget ? moneyFmt.format(budget.total_allocated) : '--');
    setText('budget-spent', budget ? moneyFmt.format(budget.total_spent) : '--');

    const critical = Number(alerts?.critical ?? 0);
    const high = Number(alerts?.high ?? 0);
    const medium = Number(alerts?.medium ?? 0);
    const low = Number(alerts?.low ?? 0);
    const totalAlerts = critical + high + medium + low;
    setText('alerts-total', totalAlerts);
    setText('alerts-critical', critical);
    setText('alerts-high', high);
    setText('alerts-medium', medium);
    setText('alerts-low', low);

    // Resource totals (if placeholders added later)
    setText('resources-employees', resources?.employees ?? '--');
    setText('resources-equipment', resources?.equipment ?? '--');
    
    console.log('Summary rendering complete');
  }

  function workloadBadge(level, percent) {
    const pct = percentFmt(percent ?? 0);
    switch (level) {
      case 'critical':
        return `<span class="utilization-pill util-critical">${pct} · Critical</span>`;
      case 'overloaded':
        return `<span class="utilization-pill util-overloaded">${pct} · Overloaded</span>`;
      case 'optimal':
        return `<span class="utilization-pill util-optimal">${pct} · Optimal</span>`;
      case 'underutilized':
      default:
        return `<span class="utilization-pill util-underutilized">${pct} · Under</span>`;
    }
  }

  function statusPill(status) {
    return `<span class="status-pill status-${status ?? 'unknown'}">${(status ?? 'unknown').replace('_', ' ')}</span>`;
  }

  function priorityChip(priority) {
    return `<span class="priority-chip priority-${priority ?? 'medium'}">${priority ?? 'medium'}</span>`;
  }

  function setSelectOptions(selectEl, items, formatFn, placeholder = 'Select...') {
    if (!selectEl) return;
    selectEl.innerHTML = '';
    const ph = document.createElement('option');
    ph.value = '';
    ph.textContent = placeholder;
    selectEl.appendChild(ph);
    items.forEach((item) => {
      const opt = document.createElement('option');
      opt.value = item.value;
      opt.textContent = formatFn(item);
      selectEl.appendChild(opt);
    });
  }

  function populateProjectSelect() {
    const select = document.getElementById('assign-project');
    if (!select) return;
    const formatted = projectsCache.map((p) => ({
      value: p.project_id,
      label: `${p.project_name} (${p.status})`,
      priority: p.priority,
    }));
    setSelectOptions(
      select,
      formatted,
      (p) => `${p.label} · ${p.priority}`,
      'Choose a project'
    );
    if (formatted.length) {
      select.value = formatted[0].value;
      select.dispatchEvent(new Event('change'));
    }
  }

  function populateTaskSelect(projectId = 0, overrideTasks = null) {
    const select = document.getElementById('assign-task');
    if (!select) return;
    const source = overrideTasks || tasksCache;
    const filtered = projectId ? source.filter((t) => Number(t.project_id) === Number(projectId)) : source;
    const formatted = filtered.map((t) => ({
      value: t.task_id,
      label: `${t.task_name} (${t.priority})`,
    }));
    setSelectOptions(select, formatted, (t) => t.label, 'Choose a task');
    if (formatted.length) select.value = formatted[0].value;
  }

  function renderResourceOptions(data) {
    const typeSelect = document.getElementById('assign-type');
    const resourceSelect = document.getElementById('assign-resource');
    if (!typeSelect || !resourceSelect) return;

    const assignmentEmployees = data.employees || [];
    const assignmentEquipment = data.equipment || [];
    const assignmentBudgets = data.budgets || budgetsCache || [];
    const type = typeSelect.value;

    if (type === 'employee') {
      setSelectOptions(
        resourceSelect,
        assignmentEmployees.map((e) => ({
          value: e.id,
          label: `${e.name} · ${percentFmt(e.utilization_percentage)} · ${e.department || e.role || ''}`,
        })),
        (e) => e.label,
        'Choose an employee'
      );
    } else if (type === 'equipment') {
      setSelectOptions(
        resourceSelect,
        assignmentEquipment.map((eq) => ({
          value: eq.id,
          label: `${eq.name} · ${eq.type} · ${percentFmt(eq.utilization_percentage)}`,
        })),
        (eq) => eq.label,
        'Choose equipment'
      );
    } else {
      setSelectOptions(
        resourceSelect,
        assignmentBudgets.map((b) => ({
          value: b.id,
          label: `${b.name} · Remaining ${moneyFmt.format(b.remaining_amount ?? 0)}`,
        })),
        (b) => b.label,
        'Choose budget'
      );
    }
  }

  function renderAlerts(alerts) {
    const list = document.getElementById('alerts-list');
    const empty = document.getElementById('alerts-empty');
    if (!list || !empty) return;

    list.innerHTML = '';
    if (!alerts || !alerts.length) {
      empty.classList.remove('d-none');
      list.classList.add('d-none');
      return;
    }
    empty.classList.add('d-none');
    list.classList.remove('d-none');

    alerts.forEach((alert) => {
      // Add null checks for safety
      const severity = alert.severity || 'low';
      const alertType = alert.alert_type || 'Unknown';
      const resourceType = alert.resource_type || 'Unknown';
      const message = alert.message || 'No message';
      const resourceId = alert.resource_id || '';
      const projectId = alert.project_id || '';
      const taskId = alert.task_id || '';
      
      // Define icons and colors based on severity
      const icons = {
        critical: 'fa-exclamation-circle',
        high: 'fa-exclamation-triangle',
        medium: 'fa-info-circle',
        low: 'fa-bell'
      };
      
      const badgeColors = {
        critical: 'danger',
        high: 'warning',
        medium: 'info',
        low: 'secondary'
      };
      
      const severityClass = `alert-${severity}`;
      const item = document.createElement('a');
      item.className = `list-group-item list-group-item-action ${severityClass}`;
      item.innerHTML = `
        <div class="d-flex align-items-start gap-3">
          <div class="alert-icon">
            <i class="fas ${icons[severity]}"></i>
          </div>
          <div class="flex-grow-1">
            <div class="alert-header">
              <h6 class="text-capitalize">${alertType.replace('_', ' ')}</h6>
              <span class="badge bg-${badgeColors[severity]}">${severity}</span>
            </div>
            <div class="alert-resource">${resourceType}</div>
            <div class="alert-message">${message}</div>
            <div class="alert-details">
              ${resourceId ? `<span class="badge"><i class="fas fa-tag me-1"></i>${resourceId}</span>` : ''}
              ${projectId ? `<span class="badge"><i class="fas fa-project-diagram me-1"></i>Project #${projectId}</span>` : ''}
              ${taskId ? `<span class="badge"><i class="fas fa-tasks me-1"></i>Task #${taskId}</span>` : ''}
            </div>
          </div>
        </div>
      `;
      list.appendChild(item);

      // Note: Toast notifications are handled separately in loadUrgentAlertsOnly
      // to ensure they appear one by one with proper timing
    });
  }

  function renderEmployees(rows) {
    const tbody = document.getElementById('employees-body');
    if (!tbody) return;
    tbody.innerHTML = '';
    if (!rows.length) {
      tbody.innerHTML = `<tr><td colspan="6" class="text-center text-muted py-4">No employees found.</td></tr>`;
      return;
    }
    rows.forEach((e) => {
      const utilization = e.latest_utilization ?? e.utilization_percentage;
      tbody.insertAdjacentHTML('beforeend', `
        <tr>
          <td>
            <div class="fw-semibold">${e.employee_name}</div>
            <div class="text-muted small">${e.email}</div>
          </td>
          <td>${e.role}</td>
          <td>${e.department ?? '—'}</td>
          <td>${statusPill(e.status)}</td>
          <td class="text-center">${workloadBadge(e.workload_level ?? 'underutilized', utilization)}</td>
          <td class="text-end">${moneyFmt.format(e.hourly_rate ?? 0)}</td>
        </tr>
      `);
    });
  }

  function renderEquipment(rows) {
    const tbody = document.getElementById('equipment-body');
    if (!tbody) return;
    tbody.innerHTML = '';
    if (!rows.length) {
      tbody.innerHTML = `<tr><td colspan="6" class="text-center text-muted py-4">No equipment found.</td></tr>`;
      return;
    }
    rows.forEach((eq) => {
      const utilization = eq.latest_utilization ?? eq.utilization_percentage;
      tbody.insertAdjacentHTML('beforeend', `
        <tr>
          <td class="fw-semibold">${eq.equipment_name}</td>
          <td>${eq.equipment_type}</td>
          <td>${eq.location ?? '—'}</td>
          <td>${statusPill(eq.status)}</td>
          <td class="text-center">${workloadBadge(eq.workload_level ?? 'underutilized', utilization)}</td>
          <td class="text-end">${moneyFmt.format(eq.hourly_rate ?? 0)}</td>
        </tr>
      `);
    });
  }

  function renderProjects(rows) {
    const tbody = document.getElementById('projects-body');
    if (!tbody) return;
    tbody.innerHTML = '';
    if (!rows.length) {
      tbody.innerHTML = `<tr><td colspan="6" class="text-center text-muted py-4">No projects found.</td></tr>`;
      return;
    }
    rows.forEach((p) => {
      const progress = Number(p.avg_progress ?? 0).toFixed(0);
      tbody.insertAdjacentHTML('beforeend', `
        <tr>
          <td class="fw-semibold">${p.project_name}</td>
          <td>${statusPill(p.status)}</td>
          <td>${priorityChip(p.priority)}</td>
          <td><small class="text-muted">${p.start_date} → ${p.end_date}</small></td>
          <td class="text-center">
            <div class="progress" style="height: 8px;">
              <div class="progress-bar" role="progressbar" style="width: ${progress}%;" aria-valuenow="${progress}" aria-valuemin="0" aria-valuemax="100"></div>
            </div>
            <small class="text-muted">${progress}%</small>
          </td>
          <td class="text-end">
            <div>${moneyFmt.format(p.budget_allocated ?? 0)}</div>
            <small class="text-muted">Spent ${moneyFmt.format(p.total_spent ?? 0)}</small>
          </td>
        </tr>
      `);
    });
  }

  function renderTasks(rows) {
    const tbody = document.getElementById('tasks-body');
    if (!tbody) return;
    tbody.innerHTML = '';
    if (!rows.length) {
      tbody.innerHTML = `<tr><td colspan="6" class="text-center text-muted py-4">No tasks found.</td></tr>`;
      return;
    }
    rows.forEach((t) => {
      const progress = Number(t.progress_percentage ?? 0).toFixed(0);
      tbody.insertAdjacentHTML('beforeend', `
        <tr>
          <td class="fw-semibold">${t.task_name}</td>
          <td>${t.project_name}</td>
          <td>${statusPill(t.status)}</td>
          <td>${priorityChip(t.priority)}</td>
          <td><small class="text-muted">${t.start_date} → ${t.end_date}</small></td>
          <td class="text-center">
            <div class="progress" style="height: 8px;">
              <div class="progress-bar bg-success" role="progressbar" style="width: ${progress}%;" aria-valuenow="${progress}" aria-valuemin="0" aria-valuemax="100"></div>
            </div>
            <small class="text-muted">${progress}%</small>
          </td>
        </tr>
      `);
    });
  }

  async function loadSummary() {
    try {
      const data = await fetchJSON('summary.php');
      renderSummary(data);
    } catch (err) {
      console.error(err);
      showToast('Failed to load summary', 'Unable to fetch summary data', 'danger');
    }
  }

  async function loadAlerts() {
    try {
      const data = await fetchJSON('alerts.php');
      renderAlerts(data.alerts || []);
    } catch (err) {
      console.error(err);
      showToast('Failed to load alerts', 'Unable to fetch alerts from server', 'danger');
    }
  }

  async function loadEmployees(query = '') {
    try {
      const data = await fetchJSON(`employees.php${query ? `?q=${encodeURIComponent(query)}` : ''}`);
      employeesCache = data.employees || [];
      renderEmployees(employeesCache);
    } catch (err) {
      console.error(err);
      showToast('Failed to load employees', 'Unable to fetch employee data', 'danger');
    }
  }

  async function loadEquipment(query = '') {
    try {
      const data = await fetchJSON(`equipment.php${query ? `?q=${encodeURIComponent(query)}` : ''}`);
      equipmentCache = data.equipment || [];
      renderEquipment(equipmentCache);
    } catch (err) {
      console.error(err);
      showToast('Failed to load equipment', 'Unable to fetch equipment data', 'danger');
    }
  }

  async function loadProjects() {
    try {
      const data = await fetchJSON('projects.php');
      projectsCache = data.projects || [];
      renderProjects(projectsCache);
      populateProjectSelect();
    } catch (err) {
      console.error(err);
      showToast('Failed to load projects', 'Unable to fetch project data', 'danger');
    }
  }

  async function loadTasks(projectId = 0) {
    try {
      const query = projectId ? `?project_id=${projectId}` : '';
      const data = await fetchJSON(`tasks.php${query}`);
      tasksCache = data.tasks || [];
      renderTasks(tasksCache);
      populateTaskSelect(projectId);
    } catch (err) {
      console.error(err);
      showToast('Failed to load tasks', 'Unable to fetch task data', 'danger');
    }
  }

  async function loadBudgets(projectId = 0) {
    try {
      const query = projectId ? `?project_id=${projectId}` : '';
      const data = await fetchJSON(`budgets.php${query}`);
      budgetsCache = data.budgets || [];
    } catch (err) {
      console.error(err);
      showToast('Failed to load budget', 'Unable to fetch budget data', 'danger');
    }
  }

  async function loadUtilization() {
    try {
      const data = await fetchJSON('utilization.php');
      renderUtilizationLists(data);
    } catch (err) {
      console.error(err);
      showToast('Failed to load utilization', 'Unable to fetch utilization data', 'danger');
    }
  }

  async function loadAssignmentOptions(projectId) {
    try {
      const data = await fetchJSON(`assignment_options.php${projectId ? `?project_id=${projectId}` : ''}`);
      if (projectId) {
        // overwrite tasks for this project in form only; table uses loadTasks
        populateTaskSelect(projectId, data.tasks || []);
        budgetsCache = data.budgets || [];
      }
      renderResourceOptions(data);
    } catch (err) {
      console.error(err);
      showToast('Failed to load options', 'Unable to fetch assignment options', 'danger');
    }
  }

  function findResourceName(type, id) {
    if (type === 'employee') {
      const match = employeesCache.find((e) => Number(e.employee_id ?? e.id) === Number(id));
      return match ? match.employee_name || match.name : `Employee #${id}`;
    }
    const match = equipmentCache.find((e) => Number(e.equipment_id ?? e.id) === Number(id));
    return match ? match.equipment_name || match.name : `Equipment #${id}`;
  }

  function renderUtilizationLists(data) {
    const underList = document.getElementById('underutilized-list');
    const overList = document.getElementById('overloaded-list');
    const latest = document.getElementById('utilization-latest');
    if (latest && data.latest_date) latest.textContent = `Latest snapshot: ${data.latest_date}`;
    if (!underList || !overList) return;

    const underItems = [
      ...(data.employees?.underutilized || []).map((e) => ({ type: 'employee', ...e })),
      ...(data.equipment?.underutilized || []).map((e) => ({ type: 'equipment', ...e })),
      ...(data.employees?.optimal || []).map((e) => ({ type: 'employee', ...e })),
      ...(data.equipment?.optimal || []).map((e) => ({ type: 'equipment', ...e })),
    ];
    const overItems = [
      ...(data.employees?.overloaded || []).map((e) => ({ type: 'employee', ...e })),
      ...(data.employees?.critical || []).map((e) => ({ type: 'employee', ...e })),
      ...(data.equipment?.overloaded || []).map((e) => ({ type: 'equipment', ...e })),
      ...(data.equipment?.critical || []).map((e) => ({ type: 'equipment', ...e })),
    ];

    underList.innerHTML = '';
    overList.innerHTML = '';

    if (!underItems.length) {
      underList.innerHTML = '<div class="list-group-item text-muted">No available capacity detected.</div>';
    } else {
      underItems.forEach((item) => {
        underList.insertAdjacentHTML(
          'beforeend',
          `<div class="list-group-item d-flex justify-content-between">
            <div>
              <strong>${findResourceName(item.type, item.resource_id)}</strong>
              <div class="text-muted">${item.type}</div>
            </div>
            <span class="utilization-pill util-underutilized">${percentFmt(item.utilization_percentage)} · ${item.workload_level}</span>
          </div>`
        );
      });
    }

    if (!overItems.length) {
      overList.innerHTML = '<div class="list-group-item text-muted">No overloaded resources.</div>';
    } else {
      overItems.forEach((item) => {
        overList.insertAdjacentHTML(
          'beforeend',
          `<div class="list-group-item d-flex justify-content-between">
            <div>
              <strong>${findResourceName(item.type, item.resource_id)}</strong>
              <div class="text-muted">${item.type}</div>
            </div>
            <span class="utilization-pill ${item.workload_level === 'critical' ? 'util-critical' : 'util-overloaded'}">${percentFmt(item.utilization_percentage)} · ${item.workload_level}</span>
          </div>`
        );
      });
    }
  }

  function bindAssignmentForm() {
    const projectSelect = document.getElementById('assign-project');
    const typeSelect = document.getElementById('assign-type');
    const resourceSelect = document.getElementById('assign-resource');
    const form = document.getElementById('assignment-form');
    const note = document.getElementById('assign-availability-note');
    const startInput = document.getElementById('assign-start');
    const endInput = document.getElementById('assign-end');

    if (startInput && endInput) {
      const today = new Date().toISOString().split('T')[0];
      if (!startInput.value) startInput.value = today;
      if (!endInput.value) endInput.value = today;
    }

    if (projectSelect) {
      projectSelect.addEventListener('change', (e) => {
        const projectId = Number(e.target.value);
        loadTasks(projectId);
        loadBudgets(projectId);
        loadAssignmentOptions(projectId);
        if (note) note.textContent = projectId ? 'Options filtered by selected project.' : 'Select a project to load tasks and resources.';
      });
    }

    if (typeSelect) {
      typeSelect.addEventListener('change', () => {
        const projectId = Number(projectSelect?.value || 0);
        loadAssignmentOptions(projectId);
      });
    }

    if (form) {
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        const projectId = Number(projectSelect?.value || 0);
        const taskId = Number(document.getElementById('assign-task')?.value || 0);
        const assignmentType = typeSelect?.value;
        const resourceId = Number(resourceSelect?.value || 0);
        const allocation_percentage = Number(document.getElementById('assign-percentage')?.value || 0);
        const allocated_hours = Number(document.getElementById('assign-hours')?.value || 0);
        const start_date = document.getElementById('assign-start')?.value;
        const end_date = document.getElementById('assign-end')?.value;
        const notes = document.getElementById('assign-notes')?.value || '';

        if (!projectId || !taskId || !assignmentType || !resourceId || !start_date || !end_date) {
          showToast('Missing Information', 'Please fill in all required fields', 'warning');
          return;
        }

        if (new Date(start_date) > new Date(end_date)) {
          showToast('Invalid Date Range', 'Start date must be before end date', 'warning');
          return;
        }

        submitAssignment({
          project_id: projectId,
          task_id: taskId,
          assignment_type: assignmentType,
          resource_id: resourceId,
          allocation_percentage,
          allocated_hours,
          start_date,
          end_date,
          notes,
        });
      });
    }
  }

  async function submitAssignment(payload) {
    try {
      await fetchJSON('assignments.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      showToast('Assignment Complete', 'Resource added to task successfully', 'success');
      loadAllData();
    } catch (err) {
      console.error(err);
      showToast('Assignment Failed', 'Unable to add resource to task', 'danger');
    }
  }

  function bindSearchInputs() {
    const employeeSearch = document.getElementById('employee-search');
    if (employeeSearch) {
      employeeSearch.addEventListener('input', (e) => loadEmployees(e.target.value));
    }

    const equipmentSearch = document.getElementById('equipment-search');
    if (equipmentSearch) {
      equipmentSearch.addEventListener('input', (e) => loadEquipment(e.target.value));
    }
  }

  function bindRefreshButtons() {
    const refreshBtn = document.getElementById('refresh-btn');
    const alertsRefresh = document.getElementById('alerts-refresh');
    const assignRefresh = document.getElementById('assign-refresh');
    if (refreshBtn) {
      refreshBtn.addEventListener('click', () => {
        showToast('Refreshing Data', 'Fetching the latest information...', 'info');
        loadAllData();
      });
    }
    if (alertsRefresh) alertsRefresh.addEventListener('click', loadAllData);
    if (assignRefresh) assignRefresh.addEventListener('click', () => {
      const projectSelect = document.getElementById('assign-project');
      const projectId = projectSelect ? Number(projectSelect.value) : 0;
      loadAssignmentOptions(projectId);
    });
  }

  function loadAll() {
    loadSummary();
    loadAlerts();
    loadEmployees();
    loadEquipment();
    loadProjects();
    loadTasks();
    loadBudgets();
    loadUtilization();
  }

  // Load all data: summary, alerts, employees, equipment, projects, tasks, budgets, utilization
  async function loadAllData() {
    try {
      console.log('Loading all data...');
      
      // Load summary data
      const summaryData = await fetchJSON('summary.php');
      console.log('Summary data:', summaryData);
      renderSummary(summaryData);
      
      // Load all alerts
      const alertsData = await fetchJSON('alerts.php');
      console.log('Alerts data:', alertsData);
      const allAlerts = alertsData.alerts || [];
      
      // Filter for urgent alerts only (critical or high severity)
      const urgentAlerts = allAlerts.filter(alert => 
        (alert.severity === 'critical' || alert.severity === 'high')
      );
      
      console.log('Urgent alerts:', urgentAlerts);
      
      // Take only first 3 urgent alerts for toasts
      const firstThreeUrgent = urgentAlerts.slice(0, 3);
      
      // Show ALL alerts in the list (not just urgent)
      renderAlerts(allAlerts);
      
      // Show toasts one by one for each urgent alert
      if (firstThreeUrgent.length > 0) {
        firstThreeUrgent.forEach((alert, index) => {
          setTimeout(() => {
            const alertType = alert.alert_type || 'Alert';
            const message = alert.message || 'Urgent alert';
            const severity = alert.severity || 'high';
            
            // Map severity to toast type
            const toastType = severity === 'critical' ? 'error' : 'warning';
            
            showToast(alertType, message, toastType);
          }, index * 1000); // 1 second delay between each
        });
      } else if (allAlerts.length > 0) {
        // If no urgent alerts but there are alerts, show a info toast
        setTimeout(() => {
          showToast('All Alerts Clear', 'No critical or high priority alerts', 'success');
        }, 500);
      }
      
      // Load all other data
      await loadEmployees();
      await loadEquipment();
      await loadProjects();
      await loadTasks();
      await loadBudgets();
      await loadUtilization();
      
      console.log('All data loaded successfully');
      
    } catch (err) {
      console.error('Error loading data:', err);
      showToast('Failed to load data', 'Unable to fetch data', 'danger');
    }
  }

  document.addEventListener('DOMContentLoaded', () => {
    console.log('resources.js DOMContentLoaded');
    bindSearchInputs();
    bindRefreshButtons();
    bindAssignmentForm();
    console.log('About to call loadAllData');
    loadAllData(); // Load all data
    // Keep periodic refresh for all data
    setInterval(loadAllData, 60000); // Refresh every 60 seconds
  });
})();
