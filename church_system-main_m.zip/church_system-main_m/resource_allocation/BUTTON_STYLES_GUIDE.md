# Resource Allocation Button Styles Guide

## Overview
Modern, responsive button designs have been added to the resource allocation module. All buttons now feature smooth transitions, hover effects, and consistent styling.

## Button Classes

### Primary Buttons
```html
<!-- Solid Primary Button -->
<button class="btn btn-primary">Primary Action</button>

<!-- Large Primary Button -->
<button class="btn btn-primary btn-lg">Large Primary</button>

<!-- Small Primary Button -->
<button class="btn btn-primary btn-sm">Small Primary</button>

<!-- Outline Primary Button -->
<button class="btn btn-outline-primary">Outline Primary</button>

<!-- Icon Button -->
<button class="btn btn-primary btn-icon"><i class="fas fa-plus"></i></button>
```

### Color Variants
- **Primary** (Blue) - Main actions: `.btn-primary`
- **Success** (Green) - Confirm/save actions: `.btn-success`
- **Danger** (Red) - Delete/destructive actions: `.btn-danger`
- **Warning** (Amber) - Alert/caution actions: `.btn-warning`
- **Info** (Cyan) - Information/secondary actions: `.btn-info`

### Button Sizes
- **Small**: `btn-sm` - For compact tables and lists
- **Medium** (default): Normal padding
- **Large**: `btn-lg` - For prominent actions

### Button Styles
- **Solid**: `.btn-{color}` - Full background color
- **Outline**: `.btn-outline-{color}` - Transparent with colored border
- **Ghost**: `.btn-ghost` - Minimal style, no background

### Special Button Types

#### Action Buttons (for tables)
```html
<button class="btn action-btn action-btn-edit">Edit</button>
<button class="btn action-btn action-btn-delete">Delete</button>
<button class="btn action-btn action-btn-view">View</button>
```

#### Filter Buttons
```html
<button class="btn filter-btn">All Resources</button>
<button class="btn filter-btn active">Active Only</button>
```

#### Icon Buttons
```html
<button class="btn-icon btn-primary"><i class="fas fa-edit"></i></button>
<button class="btn-icon btn-danger btn-sm"><i class="fas fa-trash"></i></button>
```

#### Floating Action Button (FAB)
```html
<button class="fab"><i class="fas fa-plus"></i></button>
```

#### Button Groups
```html
<div class="btn-group">
  <button class="btn btn-primary">Save</button>
  <button class="btn btn-danger">Cancel</button>
  <button class="btn btn-warning">Draft</button>
</div>
```

## Features

### Hover Effects
- Subtle lift effect (translateY -2px)
- Color darkening
- Enhanced shadow

### States
- **Default**: Normal appearance
- **Hover**: Lifted with shadow
- **Active**: Pressed state (no lift)
- **Disabled**: 60% opacity, no hover effects

### Responsive Behavior
- All buttons are touch-friendly (minimum 40px height)
- Icon buttons maintain square aspect ratio
- Block buttons stretch to container width

## CSS Classes Used

| Class | Purpose |
|-------|---------|
| `.btn` | Base button styles |
| `.btn-{color}` | Solid color buttons |
| `.btn-outline-{color}` | Outline buttons |
| `.btn-ghost` | Minimal button |
| `.btn-sm`, `.btn-lg` | Size variants |
| `.btn-icon` | Icon-only buttons |
| `.btn-block` | Full-width buttons |
| `.action-btn` | Table action buttons |
| `.filter-btn` | Filter toggle buttons |
| `.fab` | Floating action button |
| `.btn-group` | Button groups |

## Color Palette

- **Blue (Primary)**: #2563eb → #1d4ed8 (hover)
- **Green (Success)**: #10b981 → #059669 (hover)
- **Red (Danger)**: #ef4444 → #dc2626 (hover)
- **Amber (Warning)**: #f59e0b → #d97706 (hover)
- **Cyan (Info)**: #0ea5e9 → #0284c7 (hover)

## Implementation Notes

1. **Accessibility**: All buttons include `:focus` states (Bootstrap default)
2. **Performance**: Transitions use GPU-accelerated properties (transform, opacity)
3. **Consistency**: All buttons use the same 8px border-radius
4. **Touch Support**: Minimum 40px height for mobile usability
5. **Dark Mode Ready**: Colors use high contrast ratios (WCAG AA compliant)

## Migration from Bootstrap Defaults

Existing Bootstrap button classes still work, but the custom styles override for a more modern appearance:
- Improved shadows on hover
- Lift animation on hover
- Consistent spacing and sizing
- Better visual hierarchy

Apply these classes to your buttons in resource allocation pages for a unified, modern look.
