<?php
// admin_change_password.php - change admin password (only for logged-in admin)
if (session_status() == PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/includes/auth_helpers.php';
require_once __DIR__ . '/config/admin.php';
$BASE_URL = '/church_system-main_m';
if (empty($_SESSION['is_admin'])) {
    header("Location: {$BASE_URL}/admin_login.php");
    exit;
}
$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST'){
    $current = $_POST['current'] ?? '';
    $new = $_POST['new'] ?? '';
    $confirm = $_POST['confirm'] ?? '';
    if ($new !== $confirm) {
        $msg = 'New passwords do not match.';
    } elseif (strlen($new) < 8) {
        $msg = 'Password must be at least 8 characters.';
    } elseif (!verify_admin_password($current)) {
        $msg = 'Current password is incorrect.';
    } else {
        $hash = password_hash($new, PASSWORD_DEFAULT);
        set_admin_password_hash($hash);
        $msg = 'Password updated. Please log out and log in again.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Change Admin Password — iServe</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
<link rel="stylesheet" href="css/minimal.css" />
</head>
<body>
<div class="container mt-5">
  <div class="card login-card p-4 mx-auto" style="max-width:520px;">
    <h4>Change Admin Password</h4>
    <?php if ($msg): ?><div class="alert alert-info small mt-2"><?=htmlspecialchars($msg)?></div><?php endif; ?>
    <form method="post" class="mt-3">
      <div class="mb-3">
        <label class="form-label">Current password</label>
        <input name="current" type="password" class="form-control" required />
      </div>
      <div class="mb-3">
        <label class="form-label">New password</label>
        <input name="new" type="password" class="form-control" required />
      </div>
      <div class="mb-3">
        <label class="form-label">Confirm new password</label>
        <input name="confirm" type="password" class="form-control" required />
      </div>
      <div class="d-flex gap-2">
        <a href="index.php" class="btn btn-outline-secondary">Cancel</a>
        <button class="btn btn-primary">Change password</button>
      </div>
    </form>
  </div>
</div>
</body>
</html>