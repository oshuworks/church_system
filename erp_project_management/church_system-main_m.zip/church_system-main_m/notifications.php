<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Notifications - iServe</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/resources.css" />
    <link rel="stylesheet" href="css/navbar.css" />
    <link rel="stylesheet" href="css/style.css" />
    
    <style>
        .notification-card {
            transition: all 0.3s ease;
            border-left: 4px solid transparent;
        }
        
        .notification-card.unread {
            background-color: #e3f2fd;
            border-left-color: #2196f3;
        }
        
        .notification-card:hover {
            transform: translateX(5px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }
        
        .notification-badge {
            font-size: 0.75rem;
            padding: 0.25rem 0.5rem;
            border-radius: 4px;
            font-weight: 600;
        }
        
        .notification-time {
            font-size: 0.85rem;
            color: #6c757d;
        }
        
        .notification-message {
            color: #495057;
            line-height: 1.5;
        }
        
        .notification-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.2rem;
            flex-shrink: 0;
        }
        
        .notification-actions {
            opacity: 0;
            transition: opacity 0.3s ease;
        }
        
        .notification-card:hover .notification-actions {
            opacity: 1;
        }
        
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #6c757d;
        }
        
        .empty-state i {
            font-size: 4rem;
            margin-bottom: 20px;
            opacity: 0.5;
        }
        
        .filter-buttons .btn {
            border-radius: 20px;
            padding: 8px 16px;
            font-size: 0.9rem;
        }
        
        .filter-buttons .btn.active {
            font-weight: 600;
        }
        
        .stats-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 20px;
        }
        
        .stats-card .stat-number {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 5px;
        }
        
        .stats-card .stat-label {
            font-size: 0.9rem;
            opacity: 0.9;
        }
    </style>
</head>
<body class="bg-primary-bg">

<?php include 'includes/navbar.php'; ?>

<div class="container mt-4">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1><i class="fas fa-bell me-2"></i>Notifications</h1>
        <div class="d-flex gap-2">
            <button class="btn btn-outline-primary" onclick="refreshNotifications()">
                <i class="fas fa-sync-alt me-1"></i> Refresh
            </button>
            <button class="btn btn-outline-danger" onclick="clearAllRead()">
                <i class="fas fa-trash me-1"></i> Clear Read
            </button>
            <button class="btn btn-primary" onclick="markAllRead()">
                <i class="fas fa-check-double me-1"></i> Mark All Read
            </button>
        </div>
    </div>

    <!-- Stats Cards -->
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="stats-card" style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);">
                <div class="stat-number" id="total-notifications">0</div>
                <div class="stat-label">Total Notifications</div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stats-card" style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);">
                <div class="stat-number" id="unread-count">0</div>
                <div class="stat-label">Unread</div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stats-card" style="background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);">
                <div class="stat-number" id="deadline-count">0</div>
                <div class="stat-label">Deadline Alerts</div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stats-card" style="background: linear-gradient(135deg, #fa709a 0%, #fee140 100%);">
                <div class="stat-number" id="utilization-count">0</div>
                <div class="stat-label">Utilization Alerts</div>
            </div>
        </div>
    </div>

    <!-- Filter Buttons -->
    <div class="row mb-3">
        <div class="col-12">
            <div class="filter-buttons btn-group" role="group">
                <button type="button" class="btn btn-outline-dark active" data-filter="all" onclick="filterNotifications('all')">
                    <i class="fas fa-list me-1"></i> All
                </button>
                <button type="button" class="btn btn-outline-dark" data-filter="unread" onclick="filterNotifications('unread')">
                    <i class="fas fa-envelope me-1"></i> Unread
                </button>
                <button type="button" class="btn btn-outline-dark" data-filter="deadline" onclick="filterNotifications('deadline')">
                    <i class="fas fa-clock me-1"></i> Deadlines
                </button>
                <button type="button" class="btn btn-outline-dark" data-filter="utilization" onclick="filterNotifications('utilization')">
                    <i class="fas fa-chart-line me-1"></i> Utilization
                </button>
                <button type="button" class="btn btn-outline-dark" data-filter="system" onclick="filterNotifications('system')">
                    <i class="fas fa-cog me-1"></i> System
                </button>
            </div>
        </div>
    </div>

    <!-- Notifications List -->
    <div class="row">
        <div class="col-12">
            <div class="card shadow-sm">
                <div class="card-body p-0">
                    <div id="notifications-container" class="list-group list-group-flush">
                        <!-- Loading State -->
                        <div id="loading-state" class="empty-state">
                            <i class="fas fa-spinner fa-spin"></i>
                            <h5>Loading notifications...</h5>
                        </div>
                        
                        <!-- Empty State -->
                        <div id="empty-state" class="empty-state" style="display: none;">
                            <i class="fas fa-bell-slash"></i>
                            <h5>No notifications found</h5>
                            <p>You're all caught up!</p>
                        </div>
                        
                        <!-- Notifications will be inserted here -->
                        <div id="notifications-list"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Toast Container -->
<div id="toast-container" class="toast-container"></div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/main.js"></script>

<script>
let currentFilter = 'all';
let allNotifications = [];

// Initialize page
document.addEventListener('DOMContentLoaded', function() {
    console.log('Notifications page loaded');
    loadAllNotifications();
    
    // Auto-refresh every 30 seconds
    setInterval(loadAllNotifications, 30000);
});

// Load all notifications
async function loadAllNotifications() {
    showLoading();
    
    try {
        const response = await fetch(window.BASE_URL + '/api/notifications_api.php');
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (data.error) {
            throw new Error(data.error);
        }
        
        allNotifications = data.notifications || [];
        updateStats();
        renderNotifications();
        
    } catch (error) {
        console.error('Error loading notifications:', error);
        showError('Failed to load notifications');
        showEmptyState();
    }
}

// Update statistics
function updateStats() {
    const total = allNotifications.length;
    const unread = allNotifications.filter(n => !n.is_read).length;
    const deadline = allNotifications.filter(n => 
        n.notification_type && n.notification_type.includes('due_date')
    ).length;
    const utilization = allNotifications.filter(n => 
        n.notification_type && (
            n.notification_type.includes('utilization') || 
            n.notification_type.includes('balancing')
        )
    ).length;
    
    document.getElementById('total-notifications').textContent = total;
    document.getElementById('unread-count').textContent = unread;
    document.getElementById('deadline-count').textContent = deadline;
    document.getElementById('utilization-count').textContent = utilization;
}

// Filter notifications
function filterNotifications(filter) {
    currentFilter = filter;
    
    // Update button states
    document.querySelectorAll('.filter-buttons .btn').forEach(btn => {
        btn.classList.remove('active');
        if (btn.getAttribute('data-filter') === filter) {
            btn.classList.add('active');
        }
    });
    
    renderNotifications();
}

// Render notifications
function renderNotifications() {
    const container = document.getElementById('notifications-list');
    const emptyState = document.getElementById('empty-state');
    const loadingState = document.getElementById('loading-state');
    
    // Hide loading state
    loadingState.style.display = 'none';
    
    // Filter notifications based on current filter
    let filtered = allNotifications;
    
    switch(currentFilter) {
        case 'unread':
            filtered = allNotifications.filter(n => !n.is_read);
            break;
        case 'deadline':
            filtered = allNotifications.filter(n => 
                n.notification_type && n.notification_type.includes('due_date')
            );
            break;
        case 'utilization':
            filtered = allNotifications.filter(n => 
                n.notification_type && (
                    n.notification_type.includes('utilization') || 
                    n.notification_type.includes('balancing')
                )
            );
            break;
        case 'system':
            filtered = allNotifications.filter(n => 
                n.notification_type && n.notification_type.includes('alert')
            );
            break;
    }
    
    // Sort: unread first, then by date (newest first)
    filtered.sort((a, b) => {
        if (a.is_read !== b.is_read) {
            return a.is_read ? 1 : -1;
        }
        return new Date(b.created_at) - new Date(a.created_at);
    });
    
    // Show empty state if no notifications
    if (filtered.length === 0) {
        emptyState.style.display = 'block';
        container.innerHTML = '';
        return;
    }
    
    emptyState.style.display = 'none';
    
    // Render notifications
    container.innerHTML = filtered.map(notification => createNotificationCard(notification)).join('');
}

// Create notification card HTML
function createNotificationCard(notification) {
    const isUnread = !notification.is_read;
    const typeClass = getNotificationTypeClass(notification.notification_type);
    const icon = getNotificationTypeIcon(notification.notification_type);
    const timeAgo = getTimeAgo(notification.created_at);
    const badgeClass = notification.badge_class || typeClass;
    
    // Determine type label
    let typeLabel = '';
    let typeColor = '';
    
    if (notification.notification_type === 'project_due_date') {
        typeLabel = 'Project Due Today';
        typeColor = 'bg-danger';
    } else if (notification.notification_type === 'project_near_deadline') {
        typeLabel = 'Project Near Deadline';
        typeColor = 'bg-warning';
    } else if (notification.notification_type === 'task_due_date') {
        typeLabel = 'Task Due Today';
        typeColor = 'bg-danger';
    } else if (notification.notification_type === 'task_near_deadline') {
        typeLabel = 'Task Near Deadline';
        typeColor = 'bg-warning';
    } else if (notification.notification_type === 'subtask_due_date') {
        typeLabel = 'Subtask Due Today';
        typeColor = 'bg-danger';
    } else if (notification.notification_type === 'subtask_near_deadline') {
        typeLabel = 'Subtask Near Deadline';
        typeColor = 'bg-warning';
    } else if (notification.notification_type === 'over_utilization') {
        typeLabel = 'Over Utilization';
        typeColor = 'bg-danger';
    } else if (notification.notification_type === 'under_utilization') {
        typeLabel = 'Under Utilization';
        typeColor = 'bg-info';
    } else if (notification.notification_type === 'balancing_recommendation') {
        typeLabel = 'Balancing Recommendation';
        typeColor = 'bg-primary';
    } else if (notification.notification_type === 'system_alert') {
        typeLabel = 'System Alert';
        typeColor = 'bg-secondary';
    }
    
    const projectName = notification.project_name ? `<strong>${notification.project_name}</strong> - ` : '';
    const resourceName = notification.resource_name ? ` (${notification.resource_name})` : '';
    
    return `
        <div class="list-group-item notification-card ${isUnread ? 'unread' : ''}">
            <div class="d-flex align-items-start gap-3">
                <!-- Icon -->
                <div class="notification-icon" style="background-color: ${getBadgeColor(badgeClass)}; color: white;">
                    ${icon}
                </div>
                
                <!-- Content -->
                <div class="flex-grow-1">
                    <div class="d-flex justify-content-between align-items-start mb-1">
                        <div>
                            <span class="badge ${typeColor} notification-badge me-2">${typeLabel}</span>
                            ${isUnread ? '<span class="badge bg-primary notification-badge">New</span>' : ''}
                        </div>
                        <span class="notification-time">${timeAgo}</span>
                    </div>
                    
                    <div class="notification-message mb-1">
                        ${projectName}${notification.message}${resourceName}
                    </div>
                    
                    <div class="d-flex gap-2 notification-actions">
                        ${isUnread ? `
                            <button class="btn btn-sm btn-outline-primary" onclick="markAsRead(${notification.notification_id})">
                                <i class="fas fa-check me-1"></i> Mark as Read
                            </button>
                        ` : ''}
                        <button class="btn btn-sm btn-outline-danger" onclick="deleteNotification(${notification.notification_id})">
                            <i class="fas fa-trash me-1"></i> Delete
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `;
}

// Get notification type class
function getNotificationTypeClass(type) {
    switch (type) {
        case 'over_utilization': return 'bg-danger';
        case 'under_utilization': return 'bg-info';
        case 'balancing_recommendation': return 'bg-primary';
        case 'system_alert': return 'bg-secondary';
        case 'project_due_date':
        case 'task_due_date':
        case 'subtask_due_date': return 'bg-danger';
        case 'project_near_deadline':
        case 'task_near_deadline':
        case 'subtask_near_deadline': return 'bg-warning';
        default: return 'bg-primary';
    }
}

// Get notification type icon
function getNotificationTypeIcon(type) {
    switch (type) {
        case 'over_utilization': return '⚠️';
        case 'under_utilization': return '📉';
        case 'balancing_recommendation': return '⚖️';
        case 'system_alert': return '🔔';
        case 'project_due_date':
        case 'task_due_date':
        case 'subtask_due_date': return '🔴';
        case 'project_near_deadline':
        case 'task_near_deadline':
        case 'subtask_near_deadline': return '🟡';
        default: return '📋';
    }
}

// Get badge color
function getBadgeColor(badgeClass) {
    const colorMap = {
        'bg-danger': '#dc3545',
        'bg-warning': '#ffc107',
        'bg-info': '#17a2b8',
        'bg-primary': '#0d6efd',
        'bg-secondary': '#6c757d'
    };
    return colorMap[badgeClass] || '#0d6efd';
}

// Get time ago string
function getTimeAgo(dateString) {
    const now = new Date();
    const notificationDate = new Date(dateString);
    const diffInMinutes = Math.floor((now - notificationDate) / (1000 * 60));

    if (diffInMinutes < 1) return 'Just now';
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`;

    const diffInHours = Math.floor(diffInMinutes / 60);
    if (diffInHours < 24) return `${diffInHours}h ago`;

    const diffInDays = Math.floor(diffInHours / 24);
    if (diffInDays < 7) return `${diffInDays}d ago`;
    
    return notificationDate.toLocaleDateString();
}

// Mark notification as read
async function markAsRead(notificationId) {
    try {
        const formData = new FormData();
        formData.append('notification_id', notificationId);
        
        const response = await fetch(window.BASE_URL + '/api/notifications_api.php', {
            method: 'PUT',
            body: formData
        });
        
        const data = await response.json();
        
        if (data.error) {
            throw new Error(data.error);
        }
        
        showSuccess('Notification marked as read');
        loadAllNotifications();
        
    } catch (error) {
        console.error('Error marking as read:', error);
        showError('Failed to mark as read');
    }
}

// Mark all notifications as read
async function markAllRead() {
    if (!confirm('Mark all notifications as read?')) return;
    
    try {
        const formData = new FormData();
        formData.append('mark_all_read', true);
        
        const response = await fetch(window.BASE_URL + '/api/notifications_api.php', {
            method: 'PUT',
            body: formData
        });
        
        const data = await response.json();
        
        if (data.error) {
            throw new Error(data.error);
        }
        
        showSuccess('All notifications marked as read');
        loadAllNotifications();
        
    } catch (error) {
        console.error('Error marking all as read:', error);
        showError('Failed to mark all as read');
    }
}

// Delete notification
async function deleteNotification(notificationId) {
    if (!confirm('Delete this notification?')) return;
    
    try {
        const formData = new FormData();
        formData.append('notification_id', notificationId);
        
        const response = await fetch(window.BASE_URL + '/api/notifications_api.php', {
            method: 'DELETE',
            body: formData
        });
        
        const data = await response.json();
        
        if (data.error) {
            throw new Error(data.error);
        }
        
        showSuccess('Notification deleted');
        loadAllNotifications();
        
    } catch (error) {
        console.error('Error deleting notification:', error);
        showError('Failed to delete notification');
    }
}

// Clear all read notifications
async function clearAllRead() {
    if (!confirm('Clear all read notifications? This cannot be undone.')) return;
    
    try {
        const formData = new FormData();
        formData.append('clear_all', true);
        
        const response = await fetch(window.BASE_URL + '/api/notifications_api.php', {
            method: 'DELETE',
            body: formData
        });
        
        const data = await response.json();
        
        if (data.error) {
            throw new Error(data.error);
        }
        
        showSuccess('All read notifications cleared');
        loadAllNotifications();
        
    } catch (error) {
        console.error('Error clearing read notifications:', error);
        showError('Failed to clear notifications');
    }
}

// Refresh notifications
function refreshNotifications() {
    loadAllNotifications();
    showSuccess('Notifications refreshed');
}

// Show loading state
function showLoading() {
    document.getElementById('loading-state').style.display = 'block';
    document.getElementById('empty-state').style.display = 'none';
    document.getElementById('notifications-list').innerHTML = '';
}

// Show empty state
function showEmptyState() {
    document.getElementById('loading-state').style.display = 'none';
    document.getElementById('empty-state').style.display = 'block';
    document.getElementById('notifications-list').innerHTML = '';
}

// Show success message
function showSuccess(message) {
    showToast(message, 'success');
}

// Show error message
function showError(message) {
    showToast(message, 'error');
}

// Show toast notification
function showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    if (!container) return;
    
    const toast = document.createElement('div');
    toast.className = `toast-notification toast-${type}`;
    
    const icons = {
        success: '<i class="fas fa-check-circle"></i>',
        error: '<i class="fas fa-exclamation-circle"></i>',
        warning: '<i class="fas fa-exclamation-triangle"></i>',
        info: '<i class="fas fa-info-circle"></i>'
    };
    
    const icon = icons[type] || icons.info;
    
    toast.innerHTML = `
        <div class="toast-icon">${icon}</div>
        <div class="toast-content">
            <div class="toast-message">${message}</div>
        </div>
        <button type="button" class="toast-close" onclick="this.closest('.toast-notification').remove()">
            <i class="fas fa-times"></i>
        </button>
        <div class="toast-progress"><div class="toast-progress-bar" style="animation-duration: 3000ms;"></div></div>
    `;
    
    container.appendChild(toast);
    
    // Auto remove after 3 seconds
    setTimeout(() => {
        toast.style.opacity = '0';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}
</script>

</body>
</html>
