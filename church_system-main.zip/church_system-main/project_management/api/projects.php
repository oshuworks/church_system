<?php
// projects.php - API endpoint for projects management
// Clear any previous output buffers to prevent "Unexpected Character" errors
ob_start();

include '../includes/db.php';
header('Content-Type: application/json');

// Handle GET request
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        // A much more stable query. Only gets what the budgeting dropdown needs.
        // We use COALESCE to prevent NULL errors.
        $sql = "SELECT project_id, 
                       project_name, 
                       status, 
                       created_at 
                FROM projects 
                ORDER BY created_at DESC";

        $result = $conn->query($sql);
        $projects = [];

        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $projects[] = $row;
            }
        }

        // Wipe any potential PHP warnings that happened above
        ob_clean(); 
        echo json_encode($projects);

    } catch (Exception $e) {
        ob_clean();
        http_response_code(500);
        echo json_encode(['error' => $e->getMessage()]);
    }
    exit;
}

http_response_code(405);
echo json_encode(['error' => 'Method not allowed']);
?>